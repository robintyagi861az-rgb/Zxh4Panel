import type { Metadata } from "next";
import "../globals.css";

export const metadata: Metadata = {
  title: "ZXH4 Panel — SMM Reseller",
  description: "Premium social media marketing services, powered by ZXH4 Panel.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
